# StudentBot
A Chatbot for IGDTUW Website

Team Members - 

01804092020 Khushbu Yadav

04504092020 Sakshi Das

0504092020   Atiksha Gupta

05704092020 Shriya Rai

05904092020 Srishti Dabral

06904092020 Gitika Bajaj

06204092020 Tanishka Bhatia

07604092020 Shreya

